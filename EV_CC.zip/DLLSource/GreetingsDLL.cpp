#include "GreetingDLL.h"

#include <stdexcept>

using namespace std;

namespace Greetings
{
	string HelloWorld::Hello()
    {
        return "Hello World";
    }

}
